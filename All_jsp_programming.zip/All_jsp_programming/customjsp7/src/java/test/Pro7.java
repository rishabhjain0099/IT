/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.IOException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Anjani
 */
public class Pro7 extends SimpleTagSupport{
 String input;
 int start,end;
 public void setInput(String input){
 this.input=input;
 }

 public void setStart(int start){
 this.start=start;
 }

 public void setEnd(int end){
 this.end=end;
 }

 @Override
 public void doTag() throws IOException{
 JspWriter out = getJspContext().getOut();
 if(start>=0 && end<input.length()){
 for(int i=start;i<=end;i++){
 out.print(input.charAt(i)); 
}
 }
 else out.println("Invalid start or end");
 }
}