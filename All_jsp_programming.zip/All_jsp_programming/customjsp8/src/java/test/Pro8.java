/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.IOException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Anjani
 */
public class Pro8 extends SimpleTagSupport {

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
     String input;

 public void setInput(String input){
 this.input=input;
 }

 public void doTag() throws IOException{
 JspWriter out = getJspContext().getOut();
 for(int i=input.length()-1;i>=0;i--){
 out.print(input.charAt(i));
 }
 } 
}