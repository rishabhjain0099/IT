/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.IOException;
import java.util.Calendar;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Anjani
 */
public class Dtime extends SimpleTagSupport {

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    public void doTag() throws JspException, IOException
 {
 JspWriter out = getJspContext().getOut();
 try{
 out.print("Date : ");
 out.print(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+"/");
 out.print(Calendar.getInstance().get(Calendar.MONTH)+"/");
 out.print(Calendar.getInstance().get(Calendar.YEAR)+"<br>");
 out.print("Time : ");
 out.print(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)+"hr-");
 out.print(Calendar.getInstance().get(Calendar.MINUTE)+"min-");
 out.print(Calendar.getInstance().get(Calendar.SECOND)+"sec");
 }
 catch(Exception e)
 {
 System.out.println(e);
 }
 }
} 